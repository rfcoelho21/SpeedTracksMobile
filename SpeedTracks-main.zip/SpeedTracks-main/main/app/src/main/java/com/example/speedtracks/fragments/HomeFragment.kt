package com.example.speedtracks.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.speedtracks.GlobalVariables
import com.example.speedtracks.HomePage
import com.example.speedtracks.R
import com.example.speedtracks.adapters.CollectionAdapter
import com.example.speedtracks.adapters.Home_adapter
import com.example.speedtracks.databinding.FragmentHomeBinding
import com.example.speedtracks.models.Sneakers
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener


class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!


    private lateinit var recyclerHome: RecyclerView
    private lateinit var adapterHome: Home_adapter
    private var modelList = mutableListOf<String>()
    private var brandList = mutableListOf<String>()
    private var distanceList = mutableListOf<Int>()
    private var firstUsageList = mutableListOf<String>()
    private var colorList = mutableListOf<String>()
    private var sizeList = mutableListOf<String>()
    private var imagesList = mutableListOf<Int>()

    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var gv: GlobalVariables

    var items = arrayListOf<Sneakers>()


    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        gv = activity?.application as GlobalVariables

        firebaseAuth = FirebaseAuth.getInstance()

        val data = arguments

        binding.welcomeBack.text = ("Welcome back, ") + data!!.get("Username").toString()

        val uid = firebaseAuth.currentUser!!.uid
        val ref =
            FirebaseDatabase.getInstance().getReference("Users").child(uid!!).child("collection")
                .orderByChild("shoesSteps").limitToLast(3)

        val menuListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                items.clear()
                if (snapshot.exists()) {
                    for (sneakerSnapshot in snapshot.children) {
                        val sneaker = sneakerSnapshot.getValue(Sneakers::class.java)
                        items.add(sneaker!!)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
            }
        }

        ref.addListenerForSingleValueEvent(menuListener)

        recyclerHome = binding.rvRecyclerViewHome
        adapterHome = Home_adapter(
            modelList,
            brandList,
            distanceList,
            firstUsageList,
            colorList,
            sizeList,
            imagesList
        )

        recyclerHome.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        recyclerHome.adapter = adapterHome

        populateLists()

        return binding.root
    }

    private fun populateLists() {
        modelList.clear()
        brandList.clear()
        firstUsageList.clear()
        sizeList.clear()
        colorList.clear()
        distanceList.clear()
        imagesList.clear()
        if (items.count() != 0) {
            if (items.count() != 1) {
                items = items.reversed() as ArrayList<Sneakers>
            }
        }
        for (item in items) {
            brandList.add(item.brand.toString())
            modelList.add(item.pairModel.toString())
            firstUsageList.add(item.firstUsage.toString())
            sizeList.add(item.size.toString())
            colorList.add(item.color.toString())
            item.shoesSteps?.toInt()?.div(1000)?.let { distanceList.add(it) }
            when (item.brand) {
                "Nike" -> {
                    for (pair in gv.nikeModels.keys) {
                        if (gv.nikeModels[pair] == item.pairModel) {
                            imagesList.add(pair)
                            break
                        }
                    }
                }
                "Adidas" -> {
                    for (pair in gv.adidasModels.keys) {
                        if (gv.adidasModels[pair] == item.pairModel) {
                            imagesList.add(pair)
                            break
                        }
                    }
                }
                "New Balance" -> {
                    for (pair in gv.newBalanceModels.keys) {
                        if (gv.newBalanceModels[pair] == item.pairModel) {
                            imagesList.add(pair)
                            break

                        }
                    }
                }
                "Vans" -> {
                    for (pair in gv.vansModels.keys) {
                        if (gv.vansModels[pair] == item.pairModel) {
                            imagesList.add(pair)
                            break
                        }
                    }
                }
            }

        }
    }

}