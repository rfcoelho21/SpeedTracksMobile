package com.example.speedtracks.fragments

import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.speedtracks.GlobalVariables
import com.example.speedtracks.R
import com.example.speedtracks.adapters.CollectionAdapter
import com.example.speedtracks.databinding.ActivityHomePageBinding
import com.example.speedtracks.databinding.FragmentCollectionBinding
import com.example.speedtracks.models.Sneakers
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlin.collections.ArrayList

class CollectionFragment : Fragment() {
    private var _binding: FragmentCollectionBinding? = null
    private val binding get() = _binding!!

    private lateinit var recyclerCollection: RecyclerView
    private lateinit var adapterCollection: CollectionAdapter

    private var modelList = mutableListOf<String>()
    private var brandList = mutableListOf<String>()
    private var distanceList = mutableListOf<Int>()
    private var firstUsageList = mutableListOf<String>()
    private var colorList = mutableListOf<String>()
    private var sizeList = mutableListOf<String>()
    private var imagesList = mutableListOf<Int>()

    private lateinit var gv: GlobalVariables

    var items = arrayListOf<Sneakers>()
    var itemIds = arrayListOf<String>()

    private lateinit var firebaseAuth: FirebaseAuth

    val bundle = Bundle()

    private lateinit var homePageBinding: ActivityHomePageBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCollectionBinding.inflate(inflater, container, false)

        gv = activity?.application as GlobalVariables

        firebaseAuth = FirebaseAuth.getInstance()

        val uid = firebaseAuth.currentUser!!.uid
        val ref =
            FirebaseDatabase.getInstance().getReference("Users").child(uid!!).child("collection")

        val menuListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                items.clear()
                if (snapshot.exists()) {
                    if (snapshot.children.count() != items.count()) {
                        for (sneakerSnapshot in snapshot.children) {
                            val sneaker = sneakerSnapshot.getValue(Sneakers::class.java)
                            itemIds.add(sneakerSnapshot.key.toString())
                            items.add(sneaker!!)
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
            }
        }
        ref.addListenerForSingleValueEvent(menuListener)

        val inflaterHome = LayoutInflater.from(requireContext())
        inflaterHome.inflate(R.layout.activity_home_page, null)
        homePageBinding = ActivityHomePageBinding.inflate(inflaterHome)

        recyclerCollection = binding.collectionRecyclerView
        adapterCollection = CollectionAdapter(
            modelList,
            brandList,
            distanceList,
            firstUsageList,
            colorList,
            sizeList,
            imagesList,
            itemIds
        )
        recyclerCollection.layoutManager = GridLayoutManager(requireContext(), 2)
        recyclerCollection.adapter = adapterCollection

        val modelsFragment = ModelsFragment()
        binding.addButton.setOnClickListener {
            selectBrand(
                modelsFragment,
                "Models",
                homePageBinding
            )
        }

        populateLists()

        return binding.root
    }

    private fun selectBrand(
        fragment: Fragment,
        title: String = "Home",
        homePageBinding: ActivityHomePageBinding
    ) {
        val brands = arrayOf("Adidas", "New Balance", "Nike", "Vans")
        AlertDialog.Builder(requireContext())
            .setTitle("Whats the brand of your new shoes?")
            .setItems(brands) { dialog, which ->
                makeCurrentFragment(fragment, "Models $title", homePageBinding, which)
                dialog.dismiss()
            }
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .setNegativeButton("CANCEL") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }


    private fun makeCurrentFragment(
        fragment: Fragment,
        title: String = "Home",
        homePageBinding: ActivityHomePageBinding,
        selected: Int
    ) {
        homePageBinding.headerTitle.text = title
        var brand = ""
        when (selected) {
            0 -> brand = "Adidas"
            1 -> brand = "New Balance"
            2 -> brand = "Nike"
            3 -> brand = "Vans"
        }
        bundle.putString("Brand", brand)
        fragment.arguments = bundle
        parentFragmentManager.beginTransaction().apply {
            replace(R.id.fl_wrapper, fragment)
            commit()
        }
    }

    private fun populateLists() {
        modelList.clear()
        brandList.clear()
        firstUsageList.clear()
        sizeList.clear()
        colorList.clear()
        distanceList.clear()
        imagesList.clear()
        for (item in items) {
            brandList.add(item.brand.toString())
            modelList.add(item.pairModel.toString())
            firstUsageList.add(item.firstUsage.toString())
            sizeList.add(item.size.toString())
            colorList.add(item.color.toString())
            item.shoesSteps?.toInt()?.div(1000)?.let { distanceList.add(it) }
            when (item.brand) {
                "Nike" -> {
                    for (pair in gv.nikeModels.keys) {
                        if (gv.nikeModels[pair] == item.pairModel) {
                            imagesList.add(pair)
                            break
                        }
                    }
                }
                "Adidas" -> {
                    for (pair in gv.adidasModels.keys) {
                        if (gv.adidasModels[pair] == item.pairModel) {
                            imagesList.add(pair)
                            break
                        }
                    }
                }
                "New Balance" -> {
                    for (pair in gv.newBalanceModels.keys) {
                        if (gv.newBalanceModels[pair] == item.pairModel) {
                            imagesList.add(pair)
                            break

                        }
                    }
                }
                "Vans" -> {
                    for (pair in gv.vansModels.keys) {
                        if (gv.vansModels[pair] == item.pairModel) {
                            imagesList.add(pair)
                            break
                        }
                    }
                }
            }

        }
    }
}