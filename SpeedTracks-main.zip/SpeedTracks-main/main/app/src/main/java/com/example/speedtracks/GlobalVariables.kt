package com.example.speedtracks

import android.app.Application

class GlobalVariables: Application(){
    val adidasModels = mutableMapOf(
        R.drawable.zz_adidas_originals_forum_low to "Originals Forum Low",
        R.drawable.zz_adidas_originals_g_s_court to "Originals G.S. Court",
        R.drawable.zz_adidas_originals_gazelle to "Originals Gazelle",
        R.drawable.zz_adidas_originals_jeans_cordura to "Originals Jeans Cordura",
        R.drawable.zz_adidas_originals_nmd_v3 to "Originals NMD V3",
        R.drawable.zz_adidas_originals_ozweego_knit to "Originals Ozweego Knit",
        R.drawable.zz_adidas_originals_stan_smith to "Originals Stan Smith",
        R.drawable.zz_adidas_originals_stan_smith_vulc to "Originals Stan Smith Vulc",
        R.drawable.zz_adidas_originals_superstar to "Originals Superstar",
        R.drawable.zz_adidas_originals_zx22 to "Originals ZX22"
    )

    val nikeModels = mutableMapOf(
        R.drawable.zz_nike_air_force_1_07 to "Air Force 1 '07",
        R.drawable.zz_nike_air_max_90 to "Air Max 90",
        R.drawable.zz_nike_air_max_95 to "Air Max 95",
        R.drawable.zz_nike_air_max_270 to "Air Max 270",
        R.drawable.zz_nike_air_max_2021 to "Air Max 2021",
        R.drawable.zz_nike_air_max_dawn to "Air Max Dawn",
        R.drawable.zz_nike_air_max_genome to "Air Max Genome",
        R.drawable.zz_nike_kyrie_flytrap_5 to "Kyrie Flytrap 5",
        R.drawable.zz_nike_react_miler_3 to "React Miler 3",
        R.drawable.zz_nike_waffle_one_premium to "Waffle One Premium"
    )

    val newBalanceModels = mutableMapOf(
        R.drawable.zz_new_balance_57_40 to "NB 57/40",
        R.drawable.zz_new_balance_327 to "NB 327",
        R.drawable.zz_new_balance_410_trail to "NB 410 Trail",
        R.drawable.zz_new_balance_411 to "NB 411",
        R.drawable.zz_new_balance_574 to "NB 574",
        R.drawable.zz_new_balance_fresh_foam_hierro_v6 to "NB Fresh Foam Hierro v6",
        R.drawable.zz_new_balance_fresh_foam_hierro_v6_gtx to "NB Fresh Foam Hierro V6 GTX",
        R.drawable.zz_new_balance_fresh_foam_more_trail to "NB Fresh Foam More Trail",
        R.drawable.zz_new_balance_x_raheem_sterling_327 to "NB x Raheem Sterling 327",
        R.drawable.zz_new_balance_xc_72 to "NB XC-72"
    )

    val vansModels = mutableMapOf(
        R.drawable.zz_vans_66_99_19_rowley_classic to "66/99/19 Rowley Classic",
        R.drawable.zz_vans_cruze_2 to "Cruze 2",
        R.drawable.zz_vans_electric_flame_era to "Electric Flame Era",
        R.drawable.zz_vans_old_skool to "Old Skool",
        R.drawable.zz_vans_old_skool_graffiti to "Old Skool Graffiti",
        R.drawable.zz_vans_old_skool_paisley to "Old Skool Paisley",
        R.drawable.zz_vans_old_skool_quilted to "Old Skool Quilted",
        R.drawable.zz_vans_sk8_hi_flame to "Sk8-Hi Flame",
        R.drawable.zz_vans_sk8_low to "Sk8-Low",
        R.drawable.zz_vans_style_36_colour_block to "Style 36 Colour Block"
    )


}