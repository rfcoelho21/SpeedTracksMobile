package com.example.speedtracks.adapters

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.speedtracks.R
import com.example.speedtracks.fragments.DetailsFragment

class Home_adapter(
    private var models: List<String>,
    private var brands: List<String>,
    private var distances: List<Int>,
    private var firstUsage: List<String>,
    private var colors: List<String>,
    private var sizes: List<String>,
    private var images: List<Int>
) :
    RecyclerView.Adapter<Home_adapter.ViewHolder>() {

    val bundle = Bundle()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val itemModelBrand: TextView = itemView.findViewById(R.id.home_collection_model_brand)
        val itemDistance: TextView = itemView.findViewById(R.id.home_collection_distance)
        val itemFirstUsage: TextView = itemView.findViewById(R.id.home_collection_first_usage)
        val itemImage: ImageView = itemView.findViewById(R.id.home_collection_image)
        val itemColor: ImageView = itemView.findViewById(R.id.home_collection_color)
        val context = itemModelBrand.context!!

        init {
            itemView.setOnClickListener { v: View ->
                val position: Int = adapterPosition
                val fragment = DetailsFragment()
                makeCurrentFragment(fragment, position, context)
            }
        }

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val v = LayoutInflater.from(parent.context).inflate(R.layout.home_items, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemModelBrand.text = (brands[position] + models[position])
        (distances[position].toString() + " Km").also { holder.itemDistance.text = it }
        holder.itemFirstUsage.text = firstUsage[position]
        holder.itemImage.setImageResource(images[position])
        when(colors[position].lowercase()){
            "black" ->holder.itemColor.setColorFilter(ContextCompat.getColor(holder.itemColor.context, R.color.sc_black))
            "white" ->holder.itemColor.setColorFilter(ContextCompat.getColor(holder.itemColor.context, R.color.sc_white))
            "red" ->holder.itemColor.setColorFilter(ContextCompat.getColor(holder.itemColor.context, R.color.sc_red))
            "blue" ->holder.itemColor.setColorFilter(ContextCompat.getColor(holder.itemColor.context, R.color.sc_blue))
            "orange" ->holder.itemColor.setColorFilter(ContextCompat.getColor(holder.itemColor.context, R.color.sc_orange))
            else -> holder.itemColor.setColorFilter(ContextCompat.getColor(holder.itemColor.context, R.color.sc_default))
        }
    }

    override fun getItemCount(): Int {
        return models.size
    }

    private fun makeCurrentFragment(fragment: Fragment, position: Int, context: Context) {
        val activity = context as AppCompatActivity
        bundle.putString("ModelBrand", ("${brands[position]} ${models[position]}"))
        bundle.putInt("Image", images[position])
        bundle.putInt("Distance", distances[position])
        bundle.putString("First Usage", firstUsage[position])
        bundle.putString("Color", colors[position])
        bundle.putString("Page", "homePage")
        if(sizes[position] == ""){
            bundle.putString("Size", "None")
        }
        else {
            bundle.putString("Size", sizes[position])
        }
        fragment.arguments = bundle
        activity.supportFragmentManager.beginTransaction().apply {
            replace(R.id.fl_wrapper, fragment)
            commit()
        }
    }

}