package com.example.speedtracks.adapters

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.speedtracks.R
import com.example.speedtracks.databinding.ActivityHomePageBinding
import com.example.speedtracks.fragments.DetailsFragment
import com.example.speedtracks.models.Sneakers
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class History_adapter(
    private var brands: List<String>,
    private var models: List<String>,
    private var distances: List<Int>,
    private var firstUsage: List<String>,
    private var colors: List<String>,
    private var sizes: List<String>,
    private var images: List<Int>

) :
    RecyclerView.Adapter<History_adapter.ViewHolder>() {

    val bundle = Bundle()
    private lateinit var firebaseAuth: FirebaseAuth

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val itemBrand: TextView = itemView.findViewById(R.id.tv_titleHistory)
        val itemModel: TextView = itemView.findViewById(R.id.tv_descriptionHistory)
        val itemImage: ImageView = itemView.findViewById(R.id.iv_imageHistory)
        val contextThis = itemBrand.context!!


        init {
            itemView.setOnClickListener { v: View ->
                val position: Int = adapterPosition
                val options = arrayOf("Buy new ones", "Details")
                AlertDialog.Builder(contextThis)
                    .setTitle("Options")
                    .setItems(options) { dialog, which ->
                        when (which) {
                            0 -> {
                                when(brands[position]){
                                    "Adidas" -> {
                                        val currentModel = models[position].lowercase().replace(" ", "%20")
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.adidas.com/search?q=$currentModel"))
                                        contextThis.startActivity(intent)
                                    }
                                    "Nike" -> {
                                        val currentModel = models[position].lowercase().replace(" ", "%20")
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.nike.com/w?q=$currentModel"))
                                        contextThis.startActivity(intent)
                                    }
                                    "New Balance" -> {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.newbalance.com/"))
                                        contextThis.startActivity(intent)
                                    }
                                    "Vans" -> {
                                        val currentModel = models[position].lowercase().replace(" ", "+")
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.vans.pt/webapp/wcs/stores/servlet/SearchDisplay?storeId=10175&catalogId=11762&langId=-40&beginIndex=0&searchSource=Q&sType=SimpleSearch&searchTerm=$currentModel"))
                                        contextThis.startActivity(intent)
                                    }
                                }
                            }
                            1 -> {
                                val fragment = DetailsFragment()
                                makeCurrentFragment(fragment, position, contextThis)
                            }
                        }
                        dialog.dismiss()
                    }
                    .setNegativeButton("CANCEL") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .create()
                    .show()
            }
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val v = LayoutInflater.from(parent.context).inflate(R.layout.history_items, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: History_adapter.ViewHolder, position: Int) {
        holder.itemModel.text = brands[position]
        holder.itemBrand.text = models[position]
        if (images.count() > 0){
            holder.itemImage.setImageResource(images[position])
        }
    }

    override fun getItemCount(): Int {
        return brands.size
    }

    private fun makeCurrentFragment(fragment: Fragment, position: Int, context: Context) {
        val activity = context as AppCompatActivity
        bundle.putString("Brand", brands[position])
        bundle.putString("Model", models[position])
        bundle.putInt("Image", images[position])
        bundle.putInt("Distance", distances[position])
        bundle.putString("First Usage", firstUsage[position])
        bundle.putString("Color", colors[position])
        bundle.putString("Size", sizes[position])
        bundle.putString("Page", "historyPage")
        fragment.arguments = bundle
        activity.supportFragmentManager.beginTransaction().apply {
            replace(R.id.fl_wrapper, fragment)
            commit()
        }
    }

}