package com.example.speedtracks.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.speedtracks.GlobalVariables
import com.example.speedtracks.R
import com.example.speedtracks.adapters.History_adapter
import com.example.speedtracks.adapters.Home_adapter
import com.example.speedtracks.databinding.FragmentCollectionBinding
import com.example.speedtracks.databinding.FragmentHistoryBinding
import com.example.speedtracks.models.Sneakers
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener


class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!

    private lateinit var recyclerHistory: RecyclerView
    private lateinit var adapterHistory: History_adapter
    private var modelList = mutableListOf<String>()
    private var brandList = mutableListOf<String>()
    private var distanceList = mutableListOf<Int>()
    private var firstUsageList = mutableListOf<String>()
    private var colorList = mutableListOf<String>()
    private var sizeList = mutableListOf<String>()
    private var imagesList = mutableListOf<Int>()

    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var gv: GlobalVariables

    var items = arrayListOf<Sneakers>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)

        gv = activity?.application as GlobalVariables

        firebaseAuth = FirebaseAuth.getInstance()

        val uid = firebaseAuth.currentUser!!.uid
        val ref =
            FirebaseDatabase.getInstance().getReference("Users").child(uid!!).child("history")

        val menuListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                items.clear()
                if (snapshot.exists()) {
                    if (snapshot.children.count() != items.count()) {
                        for (sneakerSnapshot in snapshot.children) {
                            val sneaker = sneakerSnapshot.getValue(Sneakers::class.java)
                            items.add(sneaker!!)
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
            }
        }
        ref.addListenerForSingleValueEvent(menuListener)

        recyclerHistory = binding.rvRecyclerViewHistory
        adapterHistory = History_adapter(
            brandList,
            modelList,
            distanceList,
            firstUsageList,
            colorList,
            sizeList,
            imagesList
        )

        recyclerHistory.layoutManager = LinearLayoutManager(requireContext())
        recyclerHistory.adapter = adapterHistory



        populateLists()

        return binding.root
    }

    private fun populateLists() {
            modelList.clear()
            brandList.clear()
            firstUsageList.clear()
            sizeList.clear()
            colorList.clear()
            distanceList.clear()
            imagesList.clear()
            for (item in items) {
                modelList.add(item.pairModel.toString())
                brandList.add(item.brand.toString())
                firstUsageList.add(item.firstUsage.toString())
                sizeList.add(item.size.toString())
                colorList.add(item.color.toString())
                item.shoesSteps?.toInt()?.div(1000)?.let { distanceList.add(it) }
                when (item.brand) {
                    "Nike" -> {
                        for (pair in gv.nikeModels.keys) {
                            if (gv.nikeModels[pair] == item.pairModel) {
                                imagesList.add(pair)
                                break
                            }
                        }
                    }
                    "Adidas" -> {
                        for (pair in gv.adidasModels.keys) {
                            if (gv.adidasModels[pair] == item.pairModel) {
                                imagesList.add(pair)
                                break
                            }
                        }
                    }
                    "New Balance" -> {
                        for (pair in gv.newBalanceModels.keys) {
                            if (gv.newBalanceModels[pair] == item.pairModel) {
                                imagesList.add(pair)
                                break

                            }
                        }
                    }
                    "Vans" -> {
                        for (pair in gv.vansModels.keys) {
                            if (gv.vansModels[pair] == item.pairModel) {
                                imagesList.add(pair)
                                break
                            }
                        }
                    }

            }
        }
    }
}