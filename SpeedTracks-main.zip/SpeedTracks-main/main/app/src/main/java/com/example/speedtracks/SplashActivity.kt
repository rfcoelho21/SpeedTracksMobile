package com.example.speedtracks

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.constraintlayout.motion.widget.MotionLayout
import android.content.Intent
import android.util.Log
import com.example.speedtracks.models.Sneakers
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase

class SplashActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    private lateinit var usernameExtra: String
    private lateinit var emailExtra: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        auth = Firebase.auth
        val currentUser = auth.currentUser
        val hasCurrentUser = (currentUser != null)

        if(hasCurrentUser){
            val user = auth.currentUser
            val uid = user!!.uid

            database = FirebaseDatabase.getInstance().getReference("Users")
            database.child(uid).get().addOnSuccessListener {
                usernameExtra = it.child("name").value.toString()
                emailExtra = it.child("email").value.toString()

            }
        }

        val motionLayout = findViewById<MotionLayout>(R.id.motion_layout)
        motionLayout.addTransitionListener(object : MotionLayout.TransitionListener {
            override fun onTransitionStarted(p0: MotionLayout?, p1: Int, p2: Int) {
            }

            override fun onTransitionChange(p0: MotionLayout?, p1: Int, p2: Int, p3: Float) {
            }

            override fun onTransitionCompleted(p0: MotionLayout?, p1: Int) {
                if(hasCurrentUser){
                    noAnimation(HomePage::class.java,true)
                    finish()
                }else {
                    noAnimation(MainActivity::class.java,false)
                    finish()
                }
            }

            override fun onTransitionTrigger(p0: MotionLayout?, p1: Int, p2: Boolean, p3: Float) {
            }
        })
    }

    private fun noAnimation(anotherActivity: Class<*>, extra:Boolean) {
        val intent = Intent(this, anotherActivity)
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        if(extra){
            intent.putExtra("Username", usernameExtra)
            intent.putExtra("Email", emailExtra)
        }
        startActivity(intent)
        finish()
    }
}