package com.example.speedtracks.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Sneakers (
    var firstUsage: String? = null,
    var pairModel: String? = null,
    var brand: String? = null,
    var size: String? = null,
    var color: String? = null,
    var shoesSteps: String? = null
): Parcelable
