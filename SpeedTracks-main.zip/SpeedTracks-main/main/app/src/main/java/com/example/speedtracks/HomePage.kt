package com.example.speedtracks

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.speedtracks.databinding.ActivityHomePageBinding
import com.example.speedtracks.fragments.*

class HomePage : AppCompatActivity() {

    private lateinit var binding: ActivityHomePageBinding

    private val bundleProfile = Bundle()
    private val bundleHome = Bundle()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomePageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val historyFragment = HistoryFragment()
        val collectionFragment = CollectionFragment()
        val profileFragment = ProfileFragment()
        val settingsFragment = SettingsFragment()
        val homeFragment = HomeFragment()

        bundleProfile.putString("Username", intent.getStringExtra("Username"))

        bundleProfile.putString("Email", intent.getStringExtra("Email"))
        profileFragment.arguments = bundleProfile

        bundleHome.putString("Username", intent.getStringExtra("Username"))
        homeFragment.arguments = bundleHome

        makeCurrentFragment(homeFragment)
        binding.bottomNavigation.menu.getItem(0).isChecked = true

        binding.bottomNavigation.setOnItemSelectedListener() {
            when(it.itemId){
                R.id.ic_home -> makeCurrentFragment(homeFragment, "Home")
                R.id.ic_history -> makeCurrentFragment(historyFragment, "History")
                R.id.ic_collection -> makeCurrentFragment(collectionFragment, "Collection")
                R.id.ic_profile -> makeCurrentFragment(profileFragment, "Profile")
                R.id.ic_settings -> makeCurrentFragment(settingsFragment, "Settings")
            }
            true
        }
    }
    private fun makeCurrentFragment(fragment: Fragment, title: String = "Home") {
        binding.headerTitle.text = title
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fl_wrapper, fragment)
            commit()
        }
    }
}