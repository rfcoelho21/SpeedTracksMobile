package com.example.speedtracks

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseError
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import org.w3c.dom.Text

class GPSActivity : AppCompatActivity(), SensorEventListener {

    lateinit var firebaseAuth: FirebaseAuth
    lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    var startLatitude = 0.0
    var startLongitude = 0.0
    var endLatitude = 0.0
    var endLongitude = 0.0
    val REQUEST_CODE = 101

    var results = floatArrayOf(.1f)

    private var sensorManager: SensorManager? = null

    // variable gives the running status
    private var running = false

    // variable counts total steps
    private var totalSteps = 0f

    val ACTIVITY_RECOGNITION_REQUEST_CODE = 100
    private lateinit var database : DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gps)

        firebaseAuth = FirebaseAuth.getInstance()



        //check if permission isn't already granted, request the permission
        if (isPermissionGranted()) {
            requestPermission()
        }
        findViewById<ImageButton>(R.id.startCount).setOnClickListener {
            fetchLocation()
        }
        findViewById<ImageButton>(R.id.stopCount).setOnClickListener {
            stopCount()
        }
        findViewById<ImageButton>(R.id.reset).setOnClickListener {
            resetSteps()
        }


        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        //initializing sensorManager instance
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        getKMS()
    }

    private fun getKMS() {

        val getID = intent.getStringExtra("ID")!!
        val uid = firebaseAuth.uid
        val ref = FirebaseDatabase.getInstance().getReference("Users").child(uid!!).child("collection")
        ref.child(getID).get().addOnSuccessListener {
            if (it.exists()) {
                val exhibKM = it.child("M").value
                findViewById<TextView>(R.id.getKM).text=exhibKM.toString()

            } else {
                Toast.makeText(this, "Falha ao obter KM", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun fetchLocation() {

        val task: Task<Location> = fusedLocationProviderClient.lastLocation

        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED && ActivityCompat
                .checkSelfPermission(
                    this,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
            return
        }
        task.addOnSuccessListener {
            if (it != null) {
                val uid = firebaseAuth.uid
                val ref = FirebaseDatabase.getInstance().getReference("Users").child(uid!!)
                ref.child("LocationStart").setValue("${it.latitude}, ${it.longitude}")
                Toast.makeText(
                    applicationContext,
                    "${it.latitude}, ${it.longitude}",
                    Toast.LENGTH_SHORT
                ).show()
                startLatitude = it.latitude
                startLongitude = it.longitude

            }
        }

    }

    private fun stopCount() {
        val task: Task<Location> = fusedLocationProviderClient.lastLocation

        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED && ActivityCompat
                .checkSelfPermission(
                    this,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
            return
        }
        task.addOnSuccessListener {
            if (it != null) {
                val uid = firebaseAuth.uid
                val ref = FirebaseDatabase.getInstance().getReference("Users").child(uid!!)
                ref.child("LocationEnd").setValue("${it.latitude}, ${it.longitude}")
                Toast.makeText(
                    applicationContext,
                    "${it.latitude}, ${it.longitude}",
                    Toast.LENGTH_SHORT
                ).show()
                endLatitude = it.latitude
                endLongitude = it.longitude


                Location.distanceBetween(
                    startLatitude,
                    startLongitude,
                    endLatitude,
                    endLongitude,
                    results
                )
                val distance = results[0]
                val distanceRound = distance.toInt()

                Log.d("Simao", intent.getStringExtra("ID")!!)

                val getID = intent.getStringExtra("ID")!!

                val ref2 = FirebaseDatabase.getInstance().getReference("Users").child(uid!!).child("collection").child(getID)
                ref2.child("M").setValue("$distanceRound").toString()
                Toast.makeText(applicationContext, "$distance", Toast.LENGTH_SHORT).show()

            }

        }
    }

    private fun resetSteps(){
        findViewById<ImageButton>(R.id.reset).setOnClickListener {
            Toast.makeText(this,"Reseted", Toast.LENGTH_SHORT).show()
        }
        findViewById<ImageButton>(R.id.reset).setOnClickListener {

            val getID = intent.getStringExtra("ID")!!

            val uid = firebaseAuth.uid

            val ref = FirebaseDatabase.getInstance().getReference("Users").child(uid!!).child("collection").child(getID)


            ref.child("M").setValue("0")


            findViewById<TextView>(R.id.getKM).text="0"
        }
    }

    override fun onResume() {

        super.onResume()
        running = true

        // TYPE_STEP_COUNTER:  A constant describing a step counter sensor
        // Returns the number of steps taken by the user since the last reboot while activated
        // This sensor requires permission android.permission.ACTIVITY_RECOGNITION.
        val stepSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        if (stepSensor == null) {
            // show toast message, if there is no sensor in the device
            Toast.makeText(this, "No sensor detected on this device", Toast.LENGTH_SHORT).show()
        } else {
            // register listener with sensorManager
            sensorManager?.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        running = false
        // unregister listener
        sensorManager?.unregisterListener(this)
    }


    override fun onSensorChanged(event: SensorEvent?) {
        val getID = intent.getStringExtra("ID")!!
        // get textview by its id
        var tv_stepsTaken = findViewById<TextView>(R.id.tv_stepsTaken)
        val uid = firebaseAuth.uid
        if (running) {
            totalSteps = event!!.values[0]
            val ref = FirebaseDatabase.getInstance().getReference("Users").child(uid!!).child("collection").child(getID)
            ref.child("shoesSteps").setValue(totalSteps.toInt().toString())

            val currentSteps = totalSteps.toInt()

            tv_stepsTaken.text = ("$currentSteps")
        }
    }


    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        println("onAccuracyChanged: Sensor: $sensor; accuracy: $accuracy")
    }

    private fun requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACTIVITY_RECOGNITION),
                ACTIVITY_RECOGNITION_REQUEST_CODE
            )
        }
    }

    private fun isPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACTIVITY_RECOGNITION
        ) != PackageManager.PERMISSION_GRANTED
    }

    //handle requested permission result(allow or deny)
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            ACTIVITY_RECOGNITION_REQUEST_CODE -> {
                if ((grantResults.isNotEmpty() &&
                            grantResults[0] == PackageManager.PERMISSION_GRANTED)
                ) {
                    // Permission is granted. Continue the action or workflow
                    // in your app.
                }
            }
        }
    }

}