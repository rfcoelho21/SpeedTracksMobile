package com.example.speedtracks.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.example.speedtracks.DetailsDialogFragment
import com.example.speedtracks.GlobalVariables
import com.example.speedtracks.R
import com.example.speedtracks.databinding.FragmentDetailsBinding
import com.example.speedtracks.models.Sneakers
import com.google.firebase.database.FirebaseDatabase


class DetailsFragment : Fragment() {

    private var _binding: FragmentDetailsBinding? = null
    private val binding get() = _binding!!

    private lateinit var gv: GlobalVariables

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentDetailsBinding.inflate(inflater, container, false)

        val data = arguments


        gv = activity?.application as GlobalVariables

        binding.imageShoes.setImageResource(data!!.getInt("Image"))
        if (data.get("Brand")!= null) {
            binding.nameOfShoe.text = ("${data.get("Brand")} ${data.get("Model")}")
        }
        else {
            binding.nameOfShoe.text = data.get("ModelBrand").toString()
        }
        binding.sizeOfShoe.text = data.get("Size").toString()
        binding.colorOfShoe.text = data.get("Color").toString()
        when(data.getString("Color")?.lowercase()){
            "black" ->binding.detailsColor.setColorFilter(ContextCompat.getColor(binding.detailsColor.context, R.color.sc_black))
            "white" ->binding.detailsColor.setColorFilter(ContextCompat.getColor(binding.detailsColor.context, R.color.sc_white))
            "red" ->binding.detailsColor.setColorFilter(ContextCompat.getColor(binding.detailsColor.context, R.color.sc_red))
            "blue" ->binding.detailsColor.setColorFilter(ContextCompat.getColor(binding.detailsColor.context, R.color.sc_blue))
            "orange" ->binding.detailsColor.setColorFilter(ContextCompat.getColor(binding.detailsColor.context, R.color.sc_orange))
            else -> binding.detailsColor.setColorFilter(ContextCompat.getColor(binding.detailsColor.context, R.color.sc_default))
        }
        binding.dateOfFirstUsage.text = data.get("First Usage").toString()
        binding.countOfTotalDistance.text = data.get("Distance").toString() + " Km"
        binding.countOfRemainingDistance.text= (30 - data.getInt("Distance")).toString() + " Km"

        fun makeCurrentFragment(fragment: Fragment){
            requireActivity().supportFragmentManager.beginTransaction().apply {
                replace(R.id.fl_wrapper, fragment )
                commit()}
        }

        binding.backArrow.setOnClickListener {
            when(data.get("Page")!!) {
                "homePage" -> makeCurrentFragment(HomeFragment())
                "historyPage" -> makeCurrentFragment(HistoryFragment())
                "collectionPage" -> makeCurrentFragment(CollectionFragment())

            }


        }


        return binding.root
    }



}