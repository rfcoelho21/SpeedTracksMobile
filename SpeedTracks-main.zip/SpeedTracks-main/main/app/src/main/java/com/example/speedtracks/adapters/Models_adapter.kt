package com.example.speedtracks.adapters

import android.content.Intent
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.recyclerview.widget.RecyclerView
import com.example.speedtracks.HomePage
import com.example.speedtracks.R
import com.example.speedtracks.models.Sneakers
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

class Models_adapter(
    private var titles: List<String>,
    private var details: List<String>,
    private var images: List<Int>
) :
    RecyclerView.Adapter<Models_adapter.ViewHolder>() {
    @RequiresApi(Build.VERSION_CODES.O)
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private lateinit var state: String
        private lateinit var firebaseAuth: FirebaseAuth
        val itemTitle: TextView = itemView.findViewById(R.id.model)
        val itemDetail: TextView = itemView.findViewById(R.id.brand)
        val itemPicture: ImageView = itemView.findViewById(R.id.image)


        val context = itemDetail.context

        init {
            itemView.setOnClickListener { v: View ->
                val position: Int = adapterPosition
                itemDetail.getContext()
                firebaseAuth = FirebaseAuth.getInstance()
                val pairModel = titles[position]
                val brand = details[position]
                val addDialog = AlertDialog.Builder(context)
                val shoesSteps = "0"
                val size = "10"
                val color = "Default"
                val sdf = SimpleDateFormat("dd/MM/yyyy")
                val firstUsage = sdf.format(Date()).toString()


                val map = Sneakers(firstUsage,pairModel,brand,size,color,shoesSteps)


                //TESTE

                val inflater = LayoutInflater.from(context)
                val v2 = inflater.inflate(R.layout.add_pair,null)

                val textColor = v2.findViewById<TextView>(R.id.current_selected_pair)
                val textSize = v2.findViewById<EditText>(R.id.size)

                val addDialog2 = AlertDialog.Builder(context)
                textColor.text = "$brand $pairModel"

                val spinner = v2.findViewById<Spinner>(R.id.spinner1)
                val items = arrayOf("Select color...", "Black", "White","Red","Blue", "Orange")
                val adapter = ArrayAdapter<String>(
                    context,
                    android.R.layout.simple_spinner_dropdown_item,
                    items
                )

                spinner.adapter = adapter
               // val state = spinner.getItemAtPosition(spinner.selectedItemPosition).toString()

                addDialog2.setView(v2)

                addDialog2.setPositiveButton("Ok"){
                        dialog,_->
                    val uid = firebaseAuth.uid
                    map.color = spinner.selectedItem.toString()
                    map.size = textSize.text.toString()

                    val ref = FirebaseDatabase.getInstance().getReference("Users").child(uid!!)
                    //ref.child("collection").push().setValue("$pairModel-$brand")
                    ref.child("collection").push().setValue(map)
                    dialog.dismiss()
                    Toast.makeText(
                        itemView.context,
                        "Successfully added to your collection!",
                        Toast.LENGTH_SHORT
                    ).show()

                    dialog.dismiss()


                }
                addDialog2.setNegativeButton("Cancel"){
                        dialog,_->
                    dialog.dismiss()
                    Toast.makeText(context, "Canceled", Toast.LENGTH_SHORT).show()


                }
                addDialog2.create()
                addDialog2.show()


                //TESTE
                /*
                addDialog.setTitle("Add pair to your collection?")
                addDialog.setMessage(pairModel.toString())
                addDialog.setPositiveButton("Ok") { dialog, _ ->
                    val uid = firebaseAuth.uid


                    val ref = FirebaseDatabase.getInstance().getReference("Users").child(uid!!)
                    //ref.child("collection").push().setValue("$pairModel-$brand")
                    ref.child("collection").push().setValue(map)
                    dialog.dismiss()
                    Toast.makeText(
                        itemView.context,
                        "Successfully added to your collection!",
                        Toast.LENGTH_SHORT
                    ).show()

                }
                addDialog.setNegativeButton("Cancel") { dialog, _ ->
                    dialog.dismiss()

                }
                addDialog.create()
                addDialog.show()*/
            }

        }
    }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.models_items, parent, false)
        return ViewHolder(view)
    }


    override fun getItemCount(): Int {
        return 5
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemTitle.text = titles[position]
        holder.itemDetail.text = details[position]
        holder.itemPicture.setImageResource(images[position])
    }
}