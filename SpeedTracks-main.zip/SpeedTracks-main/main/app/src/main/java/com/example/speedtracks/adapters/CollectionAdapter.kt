package com.example.speedtracks.adapters

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.speedtracks.GPSActivity
import com.example.speedtracks.R
import com.example.speedtracks.fragments.DetailsFragment
import com.example.speedtracks.models.Sneakers
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class CollectionAdapter(
    private var models: List<String>,
    private var brands: List<String>,
    private var distances: List<Int>,
    private var firstUsage: List<String>,
    private var colors: List<String>,
    private var sizes: List<String>,
    private var images: List<Int>,
    private var itemsIds: List<String>,
) : RecyclerView.Adapter<CollectionAdapter.ViewHolder>() {

    val bundle = Bundle()
    private lateinit var firebaseAuth: FirebaseAuth

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemModelBrand: TextView = itemView.findViewById(R.id.collection_model_brand)
        val itemDistance: TextView = itemView.findViewById(R.id.collection_distance)
        val itemFirstUsage: TextView = itemView.findViewById(R.id.collection_first_usage)
        val itemImage: ImageView = itemView.findViewById(R.id.collection_image)
        val itemColor: ImageView = itemView.findViewById(R.id.collection_color)
        private val contextThis: Context = itemModelBrand.context

        init {
            itemView.setOnClickListener { v: View ->
                val position: Int = adapterPosition
                val options = arrayOf("GPS Tracker", "Add to history", "Buy new ones", "Details")
                AlertDialog.Builder(contextThis)
                    .setTitle("Options")
                    .setItems(options) { dialog, which ->
                        when (which) {
                            0 -> {
                                execAnotherActivity(GPSActivity::class.java, contextThis, itemsIds[position], true)
                            }
                            1 -> {
                                firebaseAuth = FirebaseAuth.getInstance()
                                val uid = firebaseAuth.currentUser!!.uid
                                val collectionRef =
                                    FirebaseDatabase.getInstance().getReference("Users")
                                        .child(uid!!).child("collection")
                                val historyRef =
                                    FirebaseDatabase.getInstance().getReference("Users")
                                        .child(uid!!).child("history")

                                val map = Sneakers(
                                    firstUsage[position],
                                    models[position],
                                    brands[position],
                                    sizes[position],
                                    colors[position],
                                    distances[position].toString()
                                )
                                historyRef.push().setValue(map)
                                collectionRef.child(itemsIds[position]).removeValue()
                                notifyItemRemoved(position)
                            }
                            2 -> {
                                when(brands[position]){
                                    "Adidas" -> {
                                        val currentModel = models[position].lowercase().replace(" ", "%20")
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.adidas.com/search?q=$currentModel"))
                                        contextThis.startActivity(intent)
                                    }
                                    "Nike" -> {
                                        val currentModel = models[position].lowercase().replace(" ", "%20")
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.nike.com/w?q=$currentModel"))
                                        contextThis.startActivity(intent)
                                    }
                                    "New Balance" -> {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.newbalance.com/"))
                                        contextThis.startActivity(intent)
                                    }
                                    "Vans" -> {
                                        val currentModel = models[position].lowercase().replace(" ", "+")
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.vans.pt/webapp/wcs/stores/servlet/SearchDisplay?storeId=10175&catalogId=11762&langId=-40&beginIndex=0&searchSource=Q&sType=SimpleSearch&searchTerm=$currentModel"))
                                        contextThis.startActivity(intent)
                                    }
                                }
                            }
                            3 -> {
                                val fragment = DetailsFragment()
                                makeCurrentFragment(fragment, position, contextThis)
                            }
                        }
                        dialog.dismiss()
                    }
                    .setNegativeButton("CANCEL") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .create()
                    .show()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.collection_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemModelBrand.text = ("${brands[position]} ${models[position]}")
        holder.itemDistance.text = distances[position].toString()
        holder.itemFirstUsage.text = firstUsage[position]
        holder.itemImage.setImageResource(images[position])
        when (colors[position].lowercase()) {
            "black" -> holder.itemColor.setColorFilter(
                ContextCompat.getColor(
                    holder.itemColor.context,
                    R.color.sc_black
                )
            )
            "white" -> holder.itemColor.setColorFilter(
                ContextCompat.getColor(
                    holder.itemColor.context,
                    R.color.sc_white
                )
            )
            "red" -> holder.itemColor.setColorFilter(
                ContextCompat.getColor(
                    holder.itemColor.context,
                    R.color.sc_red
                )
            )
            "blue" -> holder.itemColor.setColorFilter(
                ContextCompat.getColor(
                    holder.itemColor.context,
                    R.color.sc_blue
                )
            )
            "orange" -> holder.itemColor.setColorFilter(
                ContextCompat.getColor(
                    holder.itemColor.context,
                    R.color.sc_orange
                )
            )
            else -> holder.itemColor.setColorFilter(
                ContextCompat.getColor(
                    holder.itemColor.context,
                    R.color.sc_default
                )
            )
        }
    }

    override fun getItemCount(): Int {
        return models.size
    }

    private fun makeCurrentFragment(fragment: Fragment, position: Int, context: Context) {
        val activity = context as AppCompatActivity
        bundle.putString("ModelBrand", ("${brands[position]} ${models[position]}"))
        bundle.putInt("Image", images[position])
        bundle.putInt("Distance", distances[position])
        bundle.putString("First Usage", firstUsage[position])
        bundle.putString("Color", colors[position])
        bundle.putString("Size", sizes[position])
        bundle.putString("Page", "collectionPage")
        fragment.arguments = bundle
        activity.supportFragmentManager.beginTransaction().apply {
            replace(R.id.fl_wrapper, fragment)
            commit()
        }
    }
    private fun execAnotherActivity(anotherActivity: Class<*>, context: Context, id: String , extra:Boolean) {
        val intent = Intent(context, anotherActivity)
        if(extra){
            intent.putExtra("ID", id)
        }
        context.startActivity(intent)
    }

}