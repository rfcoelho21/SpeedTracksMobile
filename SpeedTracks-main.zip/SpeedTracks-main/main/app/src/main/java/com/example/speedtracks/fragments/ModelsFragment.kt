package com.example.speedtracks.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.speedtracks.GlobalVariables
import com.example.speedtracks.R
import com.example.speedtracks.adapters.All_models_adapter
import com.example.speedtracks.adapters.Models_adapter


class ModelsFragment : Fragment() {

    private lateinit var recyclerViewHorizontal: RecyclerView
    private lateinit var recyclerViewVertical: RecyclerView
    private lateinit var adapterHorizontal: Models_adapter
    private lateinit var adapterVertical: All_models_adapter
    private lateinit var gv: GlobalVariables

    private var modelsList = mutableListOf<String>()
    private var brandList = mutableListOf<String>()
    private var imagesList = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_models, container, false)

        gv = activity?.application as GlobalVariables

        val backBtn: ImageView = view.findViewById(R.id.back_arrow)

        val data = arguments
        recyclerViewHorizontal = view.findViewById(R.id.recyler_models_horizontal)
        recyclerViewVertical = view.findViewById(R.id.recycler_all_models)
        adapterHorizontal = Models_adapter(modelsList,brandList,imagesList)
        adapterVertical = All_models_adapter(modelsList,brandList)

        recyclerViewHorizontal.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        recyclerViewHorizontal.adapter = adapterHorizontal

        recyclerViewVertical.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewVertical.adapter = adapterVertical

        postToList(data)

        backBtn.setOnClickListener {
            val collectionFragment = CollectionFragment()
            val transaction = fragmentManager?.beginTransaction()
            transaction?.replace(R.id.fl_wrapper, collectionFragment)?.commit()
        }

        return view
    }



    private fun addTolist(title:String, description: String, image: Int){
        modelsList.add(title)
        brandList.add(description)
        imagesList.add(image)
    }

    private fun postToList(data: Bundle?){
        modelsList.clear()
        brandList.clear()
        imagesList.clear()

        var brand = data!!.get("Brand").toString()
        if (brand == "Nike"){
            var keys = gv.nikeModels.keys
            for (item in keys){
                addTolist(gv.nikeModels[item]!!,brand,item)
            }

        }
        else if (brand == "Adidas"){
            var keys = gv.adidasModels.keys
            for (item in keys){
                addTolist(gv.adidasModels[item]!!,brand,item)
            }
        }
        else if (brand == "New Balance"){
            var keys = gv.newBalanceModels.keys
            for (item in keys){
                addTolist(gv.newBalanceModels[item]!!,brand,item)
            }
        }
        else if (brand == "Vans"){
            var keys = gv.vansModels.keys
            for (item in keys){
                addTolist(gv.vansModels[item]!!,brand,item)
            }

        }
    }


}